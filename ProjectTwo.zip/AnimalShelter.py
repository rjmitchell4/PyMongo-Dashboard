from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:54180/AAC' % (username, password))
        self.database = self.client['AAC']
        
        
    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        
        # Test for valid input
        if data is not None:
            
            # Assign data (type dict)
            insert = self.database.animals.insert(data) 
            
            # If test to report result
            if insert!=0:
                print("Entry successfully added.")
            else:
                print("Entry was not successful.") 
        else:
            raise Exception("Nothing to save, because data parameter is empty")


    # Create method to implement the R in CRUD.
    def read(self, criteria):
        
        # Test if entry exists
        if criteria:
            
            #Find all instances and save them to data
            data = self.database.animals.find(criteria, {"_id":False})
            
            
            #Iterate through dict and print results
            #for i in data:
               # print(i)
                
            return data
        else:
            data = self.database.animals.find({}, {"_id":False})
            return data
        
    
    def updateOne(self, keyval1, keyval2):
        
        # Check if entries that match key/value pair exist
        if (self.database.animals.find_one(keyval1)):
            
            # Grab the entry which matches it
            old_data = self.database.animals.find_one(keyval1)
            
            # Format the second parameter the way Mongo likes it
            new_data = {'$set': keyval2}
            
            # Update the entry
            self.database.animals.update_one(old_data, new_data)
            
            #Grab the updated entry
            fixed_entry = self.database.animals.find_one(keyval2)
            
            # Success, here it is
            print("Entry was updated successfully")
            print(fixed_entry)
            
            return True
        else:
            print("No entries could be found with this parameter")
            return False
     
    def updateMany(self, keyval1, keyval2):
        
        #Check that there's at least one entry matching keyval
        if (self.database.animals.find(keyval1)):
            
            # Grab all instances of matching parameter
            old_data = self.database.animals.find(keyval1)
            
            #Format it the way Mongo likes it
            new_data = {'$set': keyval2}
            
            # Pass entries, update all of them
            self.database.animals.update_many(keyval1, new_data)
            
            # Grab the updated entries
            fixed_entries = self.database.animals.find(keyval2)
            
            #Voila, and here they are
            print("Entries were updated successfully")
            for i in fixed_entries:
                print(i)
                
            return True
        else:
            raise Exception("No entries could be found with this parameter") 
            
    def deleteOne(self, keyval):
        
        # Check to make sure there's an entry matching the description
        if (self.database.animals.find_one(keyval)):
            
            # Assign the entry to variable
            entry1 = self.database.animals.find_one(keyval)
            
            # Display the found entry to double check with User
            print(entry1)
            
            # Get input to verify that entry located was correct
            validate = input("Is this the file you wish to delete, please type \'yes\' to confirm\n")
            
            # Check it matches "yes"
            if ((validate == "yes") or (validate == "Yes")): 
                
                # Get rid of it
                self.database.animals.delete_one(keyval)
                print("Entry was deleted successfully")
                
            return True
        else:
            print("No entries could be found with this parameter")
            return False
     
    def deleteMany(self, keyval):
        
        # Check that there's at least one entry matching the request
        if (self.database.animals.find_one(keyval)):
            
            # Assign all valid entries to variable
            entry1 = self.database.animals.find(keyval)
            
            # Display all the found entries for User verification
            for i in entry1:
                print(i)
                
            # Get input from User to make certain that these entries are correct
            validate = input("Are these the files you wish to delete, please type \'yes\' to confirm\n")
            
            # Check that their response is "yes"
            if ((validate == "yes") or (validate == "Yes")): 
                
                #Get em out of here
                self.database.animals.delete_many(keyval)
                print("Entries were deleted successfully")
            return True
        else:
            print("No entries could be found with this parameter")
            return False
        
        
        
       
        
            
            
                                   
            
  